from django.apps import AppConfig


class Application5Config(AppConfig):
    name = 'application5'
